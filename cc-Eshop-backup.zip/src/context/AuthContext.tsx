import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  ReactNode,
} from 'react';

export interface User {
  id: string;
  fullName: string;
  username: string;
  email: string;
  mobile: string;
  birthDate: string;
  gender: string;
  facebook: string;
  membershipTier: string;
  accountStatus: string;
  isVerified: boolean;
}

interface AuthResponse {
  success: boolean;
  message?: string;
  user?: any;
  userId?: string;
  _id?: string;
  token?: string;
}

interface AuthContextType {
  isAuthenticated: boolean;
  isLoading: boolean;
  user: User | null;
  error: string | null;
  login: (email: string, password: string) => Promise<AuthResponse>;
  register: (userData: any) => Promise<AuthResponse>;
  logout: () => void;
  refreshUser: () => Promise<void>;
  clearError: () => void;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

// 🔥 DYNAMIC & ENVIRONMENT-AWARE BASE URL
const getApiBaseUrl = () => {
  if (import.meta.env && import.meta.env.VITE_API_BASE_URL) {
    return `${import.meta.env.VITE_API_BASE_URL}/auth`;
  }
  const hostname = window.location.hostname;
  return `http://${hostname}:8000/api/v1/auth`;
};

const API_BASE_URL = getApiBaseUrl();

// Safe extraction for FastAPI string or array error detail objects
const extractErrorMessage = (data: any, fallback: string): string => {
  if (!data) return fallback;
  if (typeof data.detail === 'string') return data.detail;
  if (Array.isArray(data.detail) && data.detail.length > 0) {
    return data.detail[0]?.msg || JSON.stringify(data.detail[0]);
  }
  if (typeof data.message === 'string') return data.message;
  return fallback;
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const getAuthHeaders = (includeAuth = true) => {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (includeAuth) {
      const token = localStorage.getItem('token') || localStorage.getItem('access_token');
      if (token) {
        headers.Authorization = `Bearer ${token}`;
      }
    }
    return headers;
  };

  const parseResponse = async (response: Response) => {
    const text = await response.text();
    try {
      return text ? JSON.parse(text) : {};
    } catch {
      return { detail: text || `Server error (Status ${response.status})` };
    }
  };

  const normalizeUser = (data: any, fallbackEmail = ''): User => {
    const source = data.user ? data.user : data;

    return {
      id: source.id || source._id || '',
      fullName: source.fullName || '',
      username: source.username || '',
      email: source.email || fallbackEmail || '',
      mobile: source.mobile || '',
      birthDate: source.birthDate || '',
      gender: source.gender || 'Other',
      facebook: source.facebook || '',
      membershipTier: source.membershipTier || 'CC Prime',
      accountStatus: source.accountStatus || source.status || 'Active',
      isVerified: !!source.isVerified,
    };
  };

  // Restore session from localStorage (runs once on mount)
  useEffect(() => {
    const storedUser = localStorage.getItem('userProfileData');
    const token = localStorage.getItem('token') || localStorage.getItem('access_token');

    if (storedUser && token) {
      try {
        const parsed = JSON.parse(storedUser);
        setUser(parsed);
        setIsAuthenticated(true);
        console.log('[AuthContext] Session restored from localStorage');
      } catch (err) {
        console.error('[AuthContext] Failed to parse stored user:', err);
        localStorage.removeItem('userProfileData');
        localStorage.removeItem('token');
        localStorage.removeItem('access_token');
      }
    } else {
      localStorage.removeItem('userProfileData');
      localStorage.removeItem('token');
      localStorage.removeItem('access_token');
    }
    setIsLoading(false);
  }, []);

  const refreshUser = useCallback(async () => {
    const token = localStorage.getItem('token') || localStorage.getItem('access_token');
    if (!token) {
      console.warn('[AuthContext] No token found – skipping refresh');
      return;
    }

    setIsLoading(true);
    setError(null);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000);

    console.log('[AuthContext] Refreshing user profile...');

    try {
      const response = await fetch(`${API_BASE_URL}/profile`, {
        method: 'GET',
        signal: controller.signal,
        headers: getAuthHeaders(),
      });
      clearTimeout(timeoutId);

      const data = await parseResponse(response);

      if (!response.ok) {
        const msg = extractErrorMessage(data, `Server returned status: ${response.status}`);
        throw new Error(msg);
      }

      console.log('[AuthContext] Profile refreshed successfully:', data);

      const updatedUser = normalizeUser(data);

      localStorage.setItem('userProfileData', JSON.stringify(updatedUser));
      setUser(updatedUser);
      setIsAuthenticated(true);
    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.error('[AuthContext] Refresh aborted due to timeout.');
        setError('Connection timed out. Check if backend is awake.');
      } else {
        console.error('[AuthContext] Refresh error:', err);
        setError(err.message || 'Failed to refresh user profile.');
      }
    } finally {
      setIsLoading(false);
    }
  }, []);

  const login = useCallback(
    async (email: string, password: string): Promise<AuthResponse> => {
      setIsLoading(true);
      setError(null);

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000);

      console.log('[AuthContext] Attempting login...');

      try {
        const response = await fetch(`${API_BASE_URL}/login`, {
          method: 'POST',
          signal: controller.signal,
          headers: getAuthHeaders(false),
          body: JSON.stringify({ email, password }),
        });
        clearTimeout(timeoutId);

        const data = await parseResponse(response);

        if (!response.ok) {
          const msg = extractErrorMessage(data, `Login failed (${response.status})`);
          setError(msg);
          return { success: false, message: msg };
        }

        const token = data.token || data.access_token;
        
        if (token) {
          // Save BOTH keys for compatibility across all HTTP utilities
          localStorage.setItem('token', token);
          localStorage.setItem('access_token', token);

          const userData = normalizeUser(data, email);

          localStorage.setItem('userProfileData', JSON.stringify(userData));
          setUser(userData);
          setIsAuthenticated(true);

          console.log('[AuthContext] Login successful');
          return { success: true, user: userData, token };
        }

        return { success: false, message: 'Login failed. No token received.' };
      } catch (err: any) {
        if (err.name === 'AbortError') {
          const msg = 'Connection timed out.';
          setError(msg);
          return { success: false, message: msg };
        }
        console.error('[AuthContext] Login error:', err);
        const msg = err.message || 'System unreachable. Ensure backend is running.';
        setError(msg);
        return { success: false, message: msg };
      } finally {
        setIsLoading(false);
      }
    },
    []
  );

  const register = useCallback(
    async (userData: any): Promise<AuthResponse> => {
      setIsLoading(true);
      setError(null);

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000);

      console.log('[AuthContext] Attempting registration...');

      try {
        const response = await fetch(`${API_BASE_URL}/register`, {
          method: 'POST',
          signal: controller.signal,
          headers: getAuthHeaders(false),
          body: JSON.stringify(userData),
        });
        clearTimeout(timeoutId);

        const data = await parseResponse(response);

        if (!response.ok) {
          const msg = extractErrorMessage(data, `Registration failed (${response.status})`);
          setError(msg);
          return { success: false, message: msg };
        }

        console.log('[AuthContext] Registration successful');
        return {
          success: true,
          user: data.user || data,
          userId: data.userId || data._id || data.user?._id || data.user?.id,
          _id: data._id || data.user?._id || data.user?.id,
        };
      } catch (err: any) {
        if (err.name === 'AbortError') {
          const msg = 'Connection timed out.';
          setError(msg);
          return { success: false, message: msg };
        }
        console.error('[AuthContext] Register error:', err);
        const msg = err.message || 'Registration failed. System unreachable.';
        setError(msg);
        return { success: false, message: msg };
      } finally {
        setIsLoading(false);
      }
    },
    []
  );

  const logout = useCallback(() => {
    console.log('[AuthContext] Logging out...');
    localStorage.removeItem('userProfileData');
    localStorage.removeItem('token');
    localStorage.removeItem('access_token');
    setUser(null);
    setIsAuthenticated(false);
    setError(null);
    window.location.href = '/login';
  }, []);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        isLoading,
        user,
        error,
        login,
        register,
        logout,
        refreshUser,
        clearError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
