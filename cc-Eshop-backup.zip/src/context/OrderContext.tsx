import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

export interface OrderItem {
  product_id: string;
  name: string;
  quantity: number;
  price: number;
  image?: string;
  sku?: string;
}

export interface ShippingAddress {
  full_name: string;
  phone?: string;
  address_line1: string;
  address_line2?: string;
  city: string;
  state?: string;
  postal_code: string;
  country: string;
}

export interface Order {
  _id?: string;
  id?: string;
  order_number?: string;
  user_id?: string;
  customer_name: string;
  customer_email: string;
  customer_phone?: string;
  items: OrderItem[];
  subtotal: number;
  shipping_fee?: number;
  tax?: number;
  total: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | string;
  payment_status: 'pending' | 'paid' | 'failed' | 'refunded' | string;
  payment_method?: string;
  shipping_address: ShippingAddress;
  notes?: string;
  created_at?: string;
  updated_at?: string;
}

interface OrderContextType {
  orders: Order[];
  isLoading: boolean;
  loading: boolean;
  error: string | null;
  fetchOrders: () => Promise<void>;
  fetchOrderById: (id: string) => Promise<Order>;
  updateOrderStatus: (id: string, status: string) => Promise<Order>;
  deleteOrder: (id: string) => Promise<void>;
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);
const API_BASE_URL = '/api/v1/orders';

// Promise deduplication
let activeFetchPromise: Promise<any> | null = null;

export const OrderProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchOrders = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      if (!activeFetchPromise) {
        console.log(`[OrderContext] Firing API request to: ${API_BASE_URL}`);

        activeFetchPromise = fetch(API_BASE_URL, {
          headers: { 'Content-Type': 'application/json' },
        }).then(async (res) => {
          if (!res.ok) throw new Error(`Server returned status: ${res.status}`);
          return res.json();
        });
      } else {
        console.log('[OrderContext] Strict Mode duplicate detected. Piggybacking on existing request...');
      }

      const data = await activeFetchPromise;

      const normalized = (Array.isArray(data) ? data : []).map((o: any) => ({
        ...o,
        id: o._id || o.id,
        total: Number(o.total || o.total_amount) || 0,
        subtotal: Number(o.subtotal || o.total_amount) || 0,
        items: Array.isArray(o.items) ? o.items : [],
        customer_name: o.customer_name || o.shipping_full_name || '',
        customer_email: o.customer_email || o.shipping_email || '',
        customer_phone: o.customer_phone || o.shipping_mobile_number || '',
        payment_status: o.payment_status || 'pending',
      }));

      setOrders(normalized);
    } catch (err: any) {
      console.error('[OrderContext] Fetch error details:', err);
      setError(err?.message || 'Failed to fetch orders.');
    } finally {
      activeFetchPromise = null;
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchOrders();
  }, [fetchOrders]);

  const fetchOrderById = async (id: string): Promise<Order> => {
    try {
      const response = await fetch(`${API_BASE_URL}/${id}`);
      if (!response.ok) throw new Error('Failed to fetch order details');

      const fullOrderData = await response.json();

      setOrders((prev) =>
        prev.map((o) => (o.id === id || o._id === id ? fullOrderData : o))
      );

      return fullOrderData;
    } catch (err) {
      console.error('[OrderContext] Failed to fetch single order:', err);
      throw err;
    }
  };

  const updateOrderStatus = async (id: string, status: string): Promise<Order> => {
    try {
      const response = await fetch(`${API_BASE_URL}/${id}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });

      if (!response.ok) throw new Error('Failed to update order status');

      const result = await response.json();
      const updatedOrder = result.order || result;

      setOrders((prev) =>
        prev.map((o) => (o.id === id || o._id === id ? updatedOrder : o))
      );
      return updatedOrder;
    } catch (err) {
      throw err;
    }
  };

  const deleteOrder = async (id: string) => {
    try {
      const response = await fetch(`${API_BASE_URL}/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('Failed to delete order');
      setOrders((prev) => prev.filter((o) => o.id !== id && o._id !== id));
    } catch (err) {
      throw err;
    }
  };

  return (
    <OrderContext.Provider
      value={{
        orders,
        isLoading,
        loading: isLoading,
        error,
        fetchOrders,
        fetchOrderById,
        updateOrderStatus,
        deleteOrder,
      }}
    >
      {children}
    </OrderContext.Provider>
  );
};

export const useOrders = () => {
  const context = useContext(OrderContext);
  if (!context) throw new Error('useOrders must be used within an OrderProvider');
  return context;
};
