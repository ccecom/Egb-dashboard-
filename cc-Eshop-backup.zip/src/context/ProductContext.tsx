import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

export interface Product {
  _id?: string;
  id?: string;
  name: string;
  description: string;
  price: number;
  compare_at_price?: number | null;
  sku: string;
  inventory: number;
  category: 'clothes' | 'perfume' | 'lifestyle' | string;
  badge?: string | null;
  sizes: string[];
  colors: string[];
  images: string[];
  specifications: Record<string, any>;
  status: string;
  created_at?: string;
  updated_at?: string;
}

interface ProductContextType {
  products: Product[];
  isLoading: boolean;
  loading: boolean;
  error: string | null;
  fetchProducts: () => Promise<void>;
  fetchProductById: (id: string) => Promise<Product>; // 🔥 Added to fetch all images
  createProduct: (productData: Partial<Product>) => Promise<Product>;
  updateProduct: (id: string, productData: Partial<Product>) => Promise<Product>;
  deleteProduct: (id: string) => Promise<void>;
}

const ProductContext = createContext<ProductContextType | undefined>(undefined);
const API_BASE_URL = '/api/v1/products';

// 🔥 Global variable for Promise Deduplication (Removes the red error)
let activeFetchPromise: Promise<any> | null = null;

export const ProductProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchProducts = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      // If there is no active request, start one and save it to the global variable
      if (!activeFetchPromise) {
        console.log(`[ProductContext] Firing API request to: ${API_BASE_URL}`);
        
        activeFetchPromise = fetch(API_BASE_URL, {
          headers: { 'Content-Type': 'application/json' }
        }).then(async (res) => {
          if (!res.ok) throw new Error(`Server returned status: ${res.status}`);
          return res.json();
        });
      } else {
        console.log('[ProductContext] Strict Mode duplicate detected. Piggybacking on existing request to avoid red errors...');
      }

      // Both initial render and Strict Mode duplicate will wait for the SAME request
      const data = await activeFetchPromise;
      
      const normalized = (Array.isArray(data) ? data : []).map((p: any) => ({
        ...p,
        id: p._id || p.id,
        price: Number(p.price) || 0,
        inventory: Number(p.inventory || p.stock || 0),
        images: Array.isArray(p.images) ? p.images : [],
      }));

      setProducts(normalized);
    } catch (err: any) {
      console.error('[ProductContext] Fetch error details:', err);
      setError(err?.message || 'Failed to fetch products.');
    } finally {
      activeFetchPromise = null;
      setIsLoading(false);
    }
  }, []);

  // Notice there is NO cleanup abort function here anymore. No more red text!
  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  // 🔥 NEW FUNCTION: Call this on your Product Details page to get all images
  const fetchProductById = async (id: string): Promise<Product> => {
    try {
      const response = await fetch(`${API_BASE_URL}/${id}`);
      if (!response.ok) throw new Error('Failed to fetch product details');
      
      const fullProductData = await response.json();
      
      // Update the local state so the specific product gets its full image array back
      setProducts((prev) => prev.map((p) => (p.id === id ? fullProductData : p)));
      
      return fullProductData;
    } catch (err) {
      console.error('[ProductContext] Failed to fetch single product:', err);
      throw err;
    }
  };

  const createProduct = async (productData: Partial<Product>) => {
    try {
      const response = await fetch(`${API_BASE_URL}/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productData),
      });
      
      if (!response.ok) {
        let errorMessage = 'Failed to create product';
        try {
          const errorData = await response.json();
          errorMessage = `Backend Error: ${JSON.stringify(errorData)}`;
        } catch (e) {}
        throw new Error(errorMessage);
      }
      
      const newProd = await response.json();
      setProducts((prev) => [newProd, ...prev]);
      return newProd;
    } catch (err: any) {
      throw err;
    }
  };

  const updateProduct = async (id: string, productData: Partial<Product>) => {
    try {
      const response = await fetch(`${API_BASE_URL}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productData),
      });
      if (!response.ok) throw new Error('Failed to update product');
      const updatedProd = await response.json();
      setProducts((prev) => prev.map((p) => (p.id === id ? updatedProd : p)));
      return updatedProd;
    } catch (err) {
      throw err;
    }
  };

  const deleteProduct = async (id: string) => {
    try {
      const response = await fetch(`${API_BASE_URL}/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('Failed to delete product');
      setProducts((prev) => prev.filter((p) => p.id !== id));
    } catch (err) {
      throw err;
    }
  };

  return (
    <ProductContext.Provider value={{ 
      products, 
      isLoading, 
      loading: isLoading, 
      error, 
      fetchProducts, 
      fetchProductById, 
      createProduct, 
      updateProduct, 
      deleteProduct 
    }}>
      {children}
    </ProductContext.Provider>
  );
};

export const useProducts = () => {
  const context = useContext(ProductContext);
  if (!context) throw new Error('useProducts must be used within a ProductProvider');
  return context;
};
