import React, { useState, useEffect } from 'react';

const Settings: React.FC = () => {
  const defaultEndpoint = "https://api.councicroff.internal";
  
  // 1. Set up state to hold the endpoint
  const [endpoint, setEndpoint] = useState(defaultEndpoint);
  const [isSaved, setIsSaved] = useState(false);

  // 2. Load the saved endpoint when the component mounts
  useEffect(() => {
    const savedEndpoint = localStorage.getItem('cc_api_endpoint');
    if (savedEndpoint) {
      setEndpoint(savedEndpoint);
    }
  }, []);

  // 3. Save the new endpoint to localStorage
  const handleSave = () => {
    localStorage.setItem('cc_api_endpoint', endpoint);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000); // Hide success message after 2s
  };

  return (
    <div className="space-y-6">
      <div>
        <p className="text-[10px] uppercase tracking-[0.4em] font-mono text-zinc-500 mb-1">CONFIGURATION KEYS // PREFERENCES</p>
        <h1 className="text-2xl font-light text-zinc-100 tracking-tight">Node Settings</h1>
      </div>
      <div className="border border-zinc-900 bg-zinc-950 p-6 max-w-xl">
        <label className="text-[10px] uppercase font-mono tracking-widest text-zinc-500 block mb-2">Ecosystem Domain Endpoint</label>
        <input 
          type="text" 
          value={endpoint}
          onChange={(e) => setEndpoint(e.target.value)}
          className="w-full bg-zinc-950 border border-zinc-900 text-zinc-300 font-mono text-xs p-3 outline-none focus:border-sky-400 mb-4"
        />
        <button 
          onClick={handleSave}
          className="bg-sky-500 hover:bg-sky-400 text-zinc-950 text-xs font-bold uppercase tracking-widest px-6 py-2 transition-colors"
        >
          {isSaved ? 'Saved!' : 'Save Configuration'}
        </button>
      </div>
    </div>
  );
};

export default Settings;
